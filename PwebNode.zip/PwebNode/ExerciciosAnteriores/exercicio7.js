var http = require('http');

var server = http.createServer(function(req,res){
	var opcao = req.url;

	if(opcao == '/sobre'){
		res.end("<html><body>Sobre a Fatec Sorocaba</body></html>");
	} else if (opcao == '/historia') {
		res.end("<html><body>História da Fatec Sorocaba</body></html>");
	} else if (opcao == '/atividades'){
		res.end("<html><body>Atividades da Fatec Sorocaba  testes</body></html>");
	} else
		res.end("<html><body>Fatec Sorocaba</body></html>");
});

server.listen(3000);